package com.cg.insure.controller;

import java.io.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/viewpolicy")
public class ViewPolicy extends HttpServlet
{
	String x="";
	RequestDispatcher rd=null;
	public void doGet(HttpServletRequest request,HttpServletResponse response) throws IOException,ServletException
	{
		
		x=request.getParameter("business_segment");
		rd= getServletContext().getRequestDispatcher("/viewpolicy.jsp");
    	rd.forward(request, response);

		
	}

}
