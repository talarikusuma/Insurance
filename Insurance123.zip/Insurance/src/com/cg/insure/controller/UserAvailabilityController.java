package com.cg.insure.controller;

import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.insure.bean.AccountBean;
import com.cg.insure.bean.IdBean;
import com.cg.insure.bean.UsernameBean;
import com.cg.insure.service.InsureService;
@WebServlet("/UserAvailability")

public class UserAvailabilityController extends HttpServlet
{
	InsureService service=new InsureService(); 
	RequestDispatcher rd = null;
	public  void doGet(HttpServletRequest request,HttpServletResponse response)
	{	 	
		try
		{
			PrintWriter out=response.getWriter();
			String user=request.getParameter("username");
			int i=service.avalability(user);
			if(i==1)
			{

				request.getRequestDispatcher("/UserAvailability.html").include(request, response);
				out.print("\n*Enter the correct Credential..");
			}
			if(i==0)
			{
				UsernameBean bean=new UsernameBean();
				bean.setUser(user);
				request.getRequestDispatcher("/accountcreate.jsp").forward(request, response);

			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
