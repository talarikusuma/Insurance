package com.cg.insure.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.insure.bean.IdBean;
import com.cg.insure.service.InsureService;
@WebServlet("/UserPolicyController")

public class UserPolicyController  extends HttpServlet 
{
	InsureService service=new InsureService();
	public  void doGet(HttpServletRequest request,HttpServletResponse response)
	{	 	
		System.out.println("1");
		try
		{
			System.out.println("2");
			RequestDispatcher rd = null;
			System.out.println("sdsdfdsfdsffsffdfs"+IdBean.getAccid());
			service.viewReport(IdBean.getAccid());
			request.getRequestDispatcher("/userreport.jsp").forward(request, response);			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}
