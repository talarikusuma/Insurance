package com.cg.insure.bean;

public class UsernameBean 
{
	public static String user;

	public static String getUser() {
		return user;
	}

	public void setUser(String user) {
		this.user = user;
	}
	

}
