package com.cg.insure.util;

import java.sql.Connection;
import java.sql.DriverManager;

import com.cg.insure.dao.InsureDao;

import oracle.jdbc.pool.OracleDataSource;

public class CommonCon 
{
	public Connection getConnection()
	{
		Connection c=null;
		try
		{
			Class.forName("oracle.jdbc.OracleDriver");
			c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg603", "training603");
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return c;

	}

}

