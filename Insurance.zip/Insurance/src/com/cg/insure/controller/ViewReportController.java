package com.cg.insure.controller;

import javax.servlet.RequestDispatcher;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.insure.service.InsureService;
@WebServlet("/ViewReportController")
public class ViewReportController extends HttpServlet
{
	InsureService service=new InsureService();
	public  void doGet(HttpServletRequest request,HttpServletResponse response)
	{
		try
		{
			RequestDispatcher rd = null;
			String temp=request.getParameter("roll");
			int id=Integer.parseInt(temp);
			service.viewReport(id);
			request.getRequestDispatcher("/viewreport.jsp").forward(request, response);			
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		

	}
}
