package com.cg.insure.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

import com.cg.insure.bean.AccountBean;
import com.cg.insure.bean.AnswerBean;
import com.cg.insure.bean.IdBean;
import com.cg.insure.bean.LoginBean;
import com.cg.insure.bean.McqAnswerBean;
import com.cg.insure.bean.PremiumBean;
import com.cg.insure.bean.QuestionBean;
import com.cg.insure.bean.UserDetailsBean;
import com.cg.insure.bean.UsernameBean;
import com.cg.insure.controller.AccountController;
import com.cg.insure.dao.InsureDao;

public class InsureService 
{
	IdBean ubean = new IdBean();
	InsureDao dao=new InsureDao();
	public void generateUserId(String user,int rollid)
	{
		UserDetailsBean bean = new UserDetailsBean();
		SimpleDateFormat geek = new SimpleDateFormat("dd"); 
	    Calendar c1 = Calendar.getInstance(); 
	    String d = geek.format(c1.getTime());
	    int id=dao.userId();
	    user+=d+id;
	    bean.setName(user);
	    bean.setPass(user);
	    bean.setRoolId(rollid);
	    ubean.setId(user);
	    dao.userDetails(bean);
	    UsernameBean bean1=new UsernameBean();
		bean1.setUser(user);
	}
	public int loginValidation(String user,String pass)
	{
		LoginBean bean= new LoginBean();
		bean.setUser(user);
		bean.setPass(pass);
		int rid =dao.LoginValidation(bean);
		if(rid<2)
		{
			System.out.println(rid);
		}
		else
		{
			System.out.println(rid);
		}
		return rid;
	}
	public int exuser(String user)
	{
		int i=0;
		i=dao.avalability(user);
		System.out.println(i);
		if(i>0)
		{
			i=i;
		}
		return i;
	}
	
	public void AccountDetails(AccountBean bean)
	{
		int id=dao.seq();
		System.out.println("service   "+AccountBean.getUsername());
		bean.setAccount_number(id);
		System.out.println(bean);
		dao.accountDetails(bean);
		ubean.setAccid(id);
	}
	public void claculatePre(PremiumBean bean)
	{
		System.out.println(bean);
		dao.weight(bean);
		int sum = bean.getP1()+bean.getP2()+bean.getP2()+bean.getP3()+bean.getP4()+bean.getP5()+bean.getP6()+bean.getP7()+bean.getP8()+bean.getP9()+bean.getP10();
		sum*=50;
		dao.premium(sum);
		System.out.println(sum);
	}
	public  void viewReport(int id1)
	{
		AnswerBean bean = new AnswerBean();
		InsureDao dao=new InsureDao();
		dao.weightList(id1);
		
		int id=PremiumBean.getId();
		dao.question(id,id1);
		if(PremiumBean.getP1()!=0)
		{
			McqAnswerBean bean1=dao.viewReport(id,QuestionBean.getQ1());
			String r=InsureService.answers(PremiumBean.getP1(),bean1);
			bean.setA1(r);
		}
		if(PremiumBean.getP2()!=0)
		{
			McqAnswerBean bean1=dao.viewReport(id,QuestionBean.getQ2());
			String r=InsureService.answers(PremiumBean.getP2(),bean1);
			bean.setA2(r);

		}
		if(PremiumBean.getP3()!=0)
		{
			McqAnswerBean bean1=dao.viewReport(id,QuestionBean.getQ3());
			String r=InsureService.answers(PremiumBean.getP3(),bean1);
			bean.setA3(r);

		}
		if(PremiumBean.getP4()!=0)
		{
			McqAnswerBean bean1=dao.viewReport(id,QuestionBean.getQ4());
			String r=InsureService.answers(PremiumBean.getP4(),bean1);
			bean.setA4(r);

		}
		if(PremiumBean.getP5()!=0)
		{
			McqAnswerBean bean1=dao.viewReport(id,QuestionBean.getQ5());
			String r=InsureService.answers(PremiumBean.getP5(),bean1);
			bean.setA5(r);

		}
		if(PremiumBean.getP6()!=0)
		{
			McqAnswerBean bean1=dao.viewReport(id,QuestionBean.getQ6());
			String r=InsureService.answers(PremiumBean.getP6(),bean1);
			bean.setA6(r);

		}
		if(PremiumBean.getP7()!=0)
		{
			McqAnswerBean bean1=dao.viewReport(id,QuestionBean.getQ7());
			String r=InsureService.answers(PremiumBean.getP7(),bean1);
			bean.setA7(r);

		}
		if(PremiumBean.getP8()!=0)
		{
			McqAnswerBean bean1=dao.viewReport(id,QuestionBean.getQ8());
			String r=InsureService.answers(PremiumBean.getP8(),bean1);
			bean.setA8(r);

		}
		if(PremiumBean.getP9()!=0)
		{
			McqAnswerBean bean1=dao.viewReport(id,QuestionBean.getQ9());
			String r=InsureService.answers(PremiumBean.getP9(),bean1);
			bean.setA9(r);

		}
		if(PremiumBean.getP10()!=0)
		{
			McqAnswerBean bean1=dao.viewReport(id,QuestionBean.getQ10());
			String r=InsureService.answers(PremiumBean.getP10(),bean1);
			bean.setA10(r);
			System.out.println(r);
		}
		
		System.out.println(bean);
		System.out.println(AccountBean.string());
		
	}
	public int avalability(String user)
	{
		int i=0;
		i=dao.avalability(user);
		if(i>0)
		{
			i=1;
		}
		System.out.println(i);
		return i;
	}
	public static String  answers(int x,McqAnswerBean bean1)
	{
		AnswerBean bean =new AnswerBean();
		String a=bean1.getA1();
		String b=bean1.getA2();
		String c=bean1.getA3();
		String r="";
		if(x==200)
		{
			r+=a;
		}
		else if(x==400)
		{
			r+=b;

		}
		else if(x==600)
		{
			r+=c;
		}
		return r;
	}
}
