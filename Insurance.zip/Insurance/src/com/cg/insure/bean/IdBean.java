package com.cg.insure.bean;

public class IdBean 
{
	private static String id;
	private static int accid;
	private static String creator;
	public static String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public static int getAccid() {
		return accid;
	}

	public  void setAccid(int accid) {
		this.accid = accid;
	}
	
	public static String getCreator() {
		return creator;
	}

	public static void setCreator(String creator) {
		IdBean.creator = creator;
	}

	@Override
	public String toString() {
		return "IdBean [id=" + id + "]";
	}
	

}
