package com.cg.insure.dao;

import java.sql.*;

import com.cg.insure.bean.AccountBean;
import com.cg.insure.bean.AnswerBean;
import com.cg.insure.bean.IdBean;
import com.cg.insure.bean.LoginBean;
import com.cg.insure.bean.McqAnswerBean;
import com.cg.insure.bean.PremiumBean;
import com.cg.insure.bean.QuestionBean;
import com.cg.insure.bean.UserDetailsBean;
import com.cg.insure.util.CommonCon;

public class InsureDao
{
	Connection c=null;
	CommonCon con=null;
	PreparedStatement ps=null;		
	ResultSet rs = null;
	UserDetailsBean beanu =new UserDetailsBean();
	PremiumBean beanp=new PremiumBean();
	public int userId()
	{
		int id=0;
		try
		{
			/*
			 * Class.forName("oracle.jdbc.OracleDriver");
			 * c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl",
			 * "trg603", "training603");
			 */
			
			c = con.getConnection();
			String seq ="Select user_seq.NEXTVAL from DUAL";
			String sql="SELECT user_seq.CURRVAL FROM DUAL";
			ps = c.prepareStatement(seq);
			rs=ps.executeQuery();
			ps = c.prepareStatement(sql);
			rs=ps.executeQuery();
			if(rs.next())
			{
				id=rs.getInt(1);
						
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return id;
	}
	public int seq()
	{
		int id=0;
		try
		{
			/*
			 * Class.forName("oracle.jdbc.OracleDriver");
			 * c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl",
			 * "trg603", "training603");
			 */
			c = con.getConnection();

			String seq ="Select seq.NEXTVAL from DUAL";
			String sql="SELECT seq.CURRVAL FROM DUAL";
			ps = c.prepareStatement(seq);
			rs=ps.executeQuery();
			ps = c.prepareStatement(sql);
			rs=ps.executeQuery();
			if(rs.next())
			{
				id=rs.getInt(1);
						
			}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		
		return id;
	}
	public void userDetails(UserDetailsBean bean)
	{
		try
		{
			/*
			 * Class.forName("oracle.jdbc.OracleDriver");
			 * c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl",
			 * "trg603", "training603");
			 */
			c = con.getConnection();
			String seq ="Insert into User_Role values(?,?,?)";
			ps = c.prepareStatement(seq);
			ps.setString(1,bean.getName());			
			ps.setString(2,bean.getPass());	
			ps.setInt(3,bean.getRoolId());	
			ps.executeUpdate();	
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
	public int LoginValidation(LoginBean bean)
	{
		int rid=0;

		try
		{
			
			String user=bean.getUser();
			String pass=bean.getPass();
			/*
			 * Class.forName("oracle.jdbc.OracleDriver");
			 * c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl",
			 * "trg603", "training603");
			 */
			c = con.getConnection();

			String sql="Select PASSWORD,ROLE_CODE from User_Role where USERNAME=?";
			ps = c.prepareStatement(sql);
			ps.setString(1,user);	
			rs=ps.executeQuery();
			String p="";
			int pass1=0;
			if(rs.next())
			{
				p=rs.getString(1);
				pass1=rs.getInt(2);
			}
			if(pass.equals(p))
			{
				rid=pass1;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}		
		return rid;
	}
	public void accountDetails(AccountBean bean)
	{
		try
		{
			/*
			 * Class.forName("oracle.jdbc.OracleDriver");
			 * c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl",
			 * "trg603", "training603");
			 */
			c = con.getConnection();
			String sql="Insert into Account values(?,?,?,?,?,?,?,?,?)";
			int insured_zip=(int) AccountBean.getInsured_zip();
			ps = c.prepareStatement(sql);
			ps.setInt(1,AccountBean.getAccount_number());			
			ps.setString(2,AccountBean.getInsured_name());	
			ps.setString(3,AccountBean.getInsured_street());
			ps.setString(4,AccountBean.getInsured_city());
			ps.setString(5,AccountBean.getInsured_state());
			ps.setInt(6,insured_zip);
			ps.setString(7,AccountBean.getBusiness_segment());
			ps.setString(9,IdBean.getCreator());
			ps.setString(8,AccountBean.getUsername());
			
			System.out.println(AccountBean.getUsername());
			IdBean bean1 = new IdBean();
			bean1.setAccid(AccountBean.getAccount_number());
			ps.executeUpdate();	
		}
		catch(Exception e)
		{
				System.err.println("User Doesnot exists......");		
		}
	}
	public void premium(int amount)
	{
		try
		{
			int id=0;
			/*
			 * Class.forName("oracle.jdbc.OracleDriver");
			 * c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl",
			 * "trg603", "training603");
			 */
			c = con.getConnection();
			String seq ="Select pol_seq.NEXTVAL from DUAL";
			String sql="SELECT pol_seq.CURRVAL FROM DUAL";
			ps = c.prepareStatement(seq);
			rs=ps.executeQuery();
			ps = c.prepareStatement(sql);
			rs=ps.executeQuery();
			if(rs.next())
			{
				id=rs.getInt(1);
						
			}
			int accno=IdBean.getAccid();
			String sqll="Insert into poli values(?,?,?)";
			ps = c.prepareStatement(sqll);
			ps.setInt(1,id);
			ps.setInt(2,amount);
			ps.setInt(3,accno);
			ps.executeUpdate();	
			beanp.setId(id);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
	}
	public void weight(PremiumBean bean)
	
	{
		try
		{
			int id=bean.getId();
			/*
			 * Class.forName("oracle.jdbc.OracleDriver");
			 * c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl",
			 * "trg603", "training603");
			 */
			c = con.getConnection();
			String sql="Insert into weight values(?,?,?,?,?,?,?,?,?,?,?,?)";
			ps = c.prepareStatement(sql);
			ps.setInt(2,bean.getP1());
			ps.setInt(3,bean.getP2());
			ps.setInt(4,bean.getP3());
			ps.setInt(5,bean.getP4());
			ps.setInt(6,bean.getP5());
			ps.setInt(7,bean.getP6());
			ps.setInt(8,bean.getP7());
			ps.setInt(9,bean.getP8());
			ps.setInt(10,bean.getP9());
			ps.setInt(11,bean.getP10());
			ps.setInt(12,IdBean.getAccid());
			ps.setInt(1,bean.getId());
			ps.executeUpdate();	
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	
	public void weightList(int id)
	{
		int i=0;
		try
		{
			/*
			 * Class.forName("oracle.jdbc.OracleDriver");
			 * c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl",
			 * "trg603", "training603");
			 */
			c = con.getConnection();
			String sql ="select BUSINESS_SEGMENT from account where account_number='"+id+"' ";
			ps = c.prepareStatement(sql);
			rs=ps.executeQuery();
			if(rs.next())
			{
				i=rs.getInt(1);
						
			}
			String sql1 ="select id,w1,w2,w3,w4,w5,w6,w7,w8,w9,w10 from weight where id='"+i+"' AND accno='"+id+"'";
			ps = c.prepareStatement(sql1);
			rs=ps.executeQuery();
			while(rs.next())
			{
				beanp.setId(rs.getInt(1));
				beanp.setP1(rs.getInt(2));
				beanp.setP2(rs.getInt(3));
				beanp.setP3(rs.getInt(4));
				beanp.setP4(rs.getInt(5));
				beanp.setP5(rs.getInt(6));
				beanp.setP6(rs.getInt(7));
				beanp.setP7(rs.getInt(8));
				beanp.setP8(rs.getInt(9));
				beanp.setP9(rs.getInt(10));
				beanp.setP10(rs.getInt(11));				
			}
			System.out.println(beanp);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

	}
	public void question(int id,int id1)
	{
		AccountBean abean = new AccountBean();
		QuestionBean bean = new QuestionBean();
		try
		{
			/*
			 * Class.forName("oracle.jdbc.OracleDriver");
			 * c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl",
			 * "trg603", "training603");
			 */
			c = con.getConnection();
			System.out.println();
			System.out.println(id);
			System.out.println();
			String sql1 ="select ACCOUNT_NUMBER,INSURED_NAME,INSURED_STREET,INSURED_CITY,INSURED_STATE,INSURED_ZIP  from account where ACCOUNT_NUMBER='"+id1+"'";
			ps = c.prepareStatement(sql1);
			rs=ps.executeQuery();
			while(rs.next())
			{
				abean.setAccount_number(rs.getInt(1));
				abean.setInsured_name(rs.getString(2));
				abean.setInsured_street(rs.getString(3));
				abean.setInsured_city(rs.getString(4));
				abean.setInsured_state(rs.getString(5));
				abean.setInsured_zip(rs.getInt(6));
			}
			if(id==1)
			{
				Statement stmt = c.createStatement();
		        rs = stmt.executeQuery("Select q1,q2,q3,q4,q5,q6,q7,q8,q9,q10 from questions where  id='"+id+"'");
				while(rs.next())
				{
					bean.setQ1(rs.getString(1));
					bean.setQ2(rs.getString(2));
					bean.setQ3(rs.getString(3));
					bean.setQ4(rs.getString(4));
					bean.setQ5(rs.getString(5));
					bean.setQ6(rs.getString(6));
					bean.setQ7(rs.getString(7));
					bean.setQ8(rs.getString(8));
					bean.setQ9(rs.getString(9));
					bean.setQ10(rs.getString(10));
			    }
			}
		
			if(id==2)
			{
				Statement stmt = c.createStatement();
		        rs = stmt.executeQuery("Select q1,q2,q3,q4,q5,q6,q7,q8,q9 from questions where  id='"+id+"'");
				while(rs.next())
				{
					bean.setQ1(rs.getString(1));
					bean.setQ2(rs.getString(2));
					bean.setQ3(rs.getString(3));
					bean.setQ4(rs.getString(4));
					bean.setQ5(rs.getString(5));
					bean.setQ6(rs.getString(6));
					bean.setQ7(rs.getString(7));
					bean.setQ8(rs.getString(8));
					bean.setQ9(rs.getString(9));
				}
			}
			if(id==3||id==4)
			{
				Statement stmt = c.createStatement();
		        rs = stmt.executeQuery("Select q1,q2,q3,q4,q5,q6,q7,q8 from questions where  id='"+id+"'");
				while(rs.next())
				{
					bean.setQ1(rs.getString(1));
					bean.setQ2(rs.getString(2));
					bean.setQ3(rs.getString(3));
					bean.setQ4(rs.getString(4));
					bean.setQ5(rs.getString(5));
					bean.setQ6(rs.getString(6));
					bean.setQ7(rs.getString(7));
					bean.setQ8(rs.getString(8));
			    }
			}
			System.out.println(bean);
	}
	catch(Exception e)
	{
		e.printStackTrace();
	}
	}
	public McqAnswerBean viewReport(int id,String str)
	{
		McqAnswerBean bean = new McqAnswerBean();
		try
		{
			/*
			 * Class.forName("oracle.jdbc.OracleDriver");
			 * c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl",
			 * "trg603", "training603");
			 */
			c = con.getConnection();
			String sql="Select  POL_QUES_ANS1,POL_QUES_ANS2,POL_QUES_ANS3 from policy_questions where POL_QUES_DESC='"+str+"' And BUS_SEG_ID='"+id+"'";
			PreparedStatement pps = c.prepareStatement(sql);
			rs=pps.executeQuery();
			if(rs.next())
			{
				bean.setA1(rs.getString(1));
				bean.setA2(rs.getString(2));
				bean.setA3(rs.getString(3));						
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();

		}
		return bean;
	}
	public int avalability(String user)
	{
		int i=1;
		int f=0;
		try
		{
			int r=0,r1=0;
			String x=null;
			/*
			 * Class.forName("oracle.jdbc.OracleDriver");
			 * c=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl",
			 * "trg603", "training603");
			 */
			c = con.getConnection();
			String sql="Select ACCOUNT_NUMBER from account where USERNAME='"+user+"'";
			String sql1="Select USERNAME from user_role where USERNAME='"+user+"'";
			PreparedStatement pps = c.prepareStatement(sql);
			rs=pps.executeQuery();
			if(rs.next())
			{
				f=rs.getInt(1);
			}
			PreparedStatement pp1 = c.prepareStatement(sql1);
			rs=pp1.executeQuery();
			if(rs.next())
			{
				x=rs.getString(1);
			}
			if(f>0)
			{
				IdBean bean2=new IdBean();
				bean2.setAccid(f);
				r=1;
			}
			if(x!=null)
			{
				r1=1;
			}
			if(r==0&&r1==1)
			{
				i=0;
			}
			if(r==1&&r1==1)
			{
				i=1;
			}
			
		}
		catch(Exception e)
		{
			e.printStackTrace();

		}
		System.out.println(i);
		return i;
	}
}
