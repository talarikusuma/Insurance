import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/login1")
public class OptionsSelection extends HttpServlet{
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		int i=0;
		final int p = 50;
			//res.setContentType("text/html");
			PrintWriter out = res.getWriter();
			//String veh_type=req.getParameter("type");
			//HttpSession session = req.getSession();
			//String a=req.getParameter("limit");
			
			try {
				ResultSet rs;
				Statement stmt;
				System.out.println("connected");
				Connection con = null;
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg603", "training603");
				stmt=con.createStatement();
				System.out.println("connected");
				//Statement st = null;
				//PreparedStatement ps=null;
				/*String query = "insert into table1 values(?,?)";//answers
				ps=con.prepareStatement(query);
				ps.setInt(1,i);
				ps.setInt(2,c);*/
				String query = "select pol_ques_desc,pol_ques_ans1,pol_ques_ans2,pol_ques_ans3 from policy_questions where bus_seg_id=1";
			rs=stmt.executeQuery(query);
			out.println("<html><body><table>");
			while(rs.next())
			{
			//keep table tag	
				out.print("<tr><td>"+rs.getString(1)+"</td>"+"   ");
				out.print("<td>"+rs.getString(2)+"<input type='radio' name='option1' value='option1'></td>"+" ");
			out.print("<td>"+rs.getString(3)+"<input type='radio' name='option1' value='option2' ></td>"+" ");
				out.println("<td>"+rs.getString(4)+"<input type='radio' name='option1' value='option3' ></td></tr>"+" ");
			}
			out.println("</table></body></html>");
				} catch(Exception ex){
					ex.printStackTrace();
				}
		}

}
