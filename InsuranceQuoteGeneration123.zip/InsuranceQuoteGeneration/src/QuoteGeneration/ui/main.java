package QuoteGeneration.ui;

public class main {

}
