package QuoteGeneration.bean;

public class bean {
	
	

}
