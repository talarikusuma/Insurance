package QuoteGeneration.controller;

import javax.servlet.http.HttpServlet;

public class controller extends HttpServlet{
	
	
}
