import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
@WebServlet("/login")
public class AddPremium extends HttpServlet{
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		int i=0;
		final int p = 50;
			res.setContentType("text/html");
			PrintWriter out = res.getWriter();
			String veh_type=req.getParameter("type");
			HttpSession session = req.getSession();
			String a=req.getParameter("limit");
			int ccl=Integer.parseInt(a);
			int veh_typ_res=veh_type(veh_type);
			int coverage_limit=coverageLimit(ccl);
			//System.out.println(i);
			//System.out.println(c);
			int prem = (veh_typ_res+coverage_limit)*p;
			System.out.println(prem);
			try {

				System.out.println("connected");
				Connection con = null;
				Class.forName("oracle.jdbc.driver.OracleDriver");
				con = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521/orcl", "trg623", "training623");
				System.out.println("connected");
				//Statement st = null;
				PreparedStatement ps=null;
				/*String query = "insert into table1 values(?,?)";//answers
				ps=con.prepareStatement(query);
				ps.setInt(1,i);
				ps.setInt(2,c);*/
				String query = "insert into premium values(?,?)";
				ps=con.prepareStatement(query);
				ps.setInt(1, 101);
				ps.setInt(2, prem);
				ps.executeUpdate();
				} catch(Exception ex){
					System.out.println(ex);
				}
		}
public int veh_type(String veh_type)
{
	int i = 0;
	if(veh_type.equals("light"))
	{
		i=200;
	}
	else if(veh_type.equals("heavy"))
	{
		i=400;
	}
	else if(veh_type.equals("truck"))
	{
		i=600;	
	}
	return i;
	
}
public int coverageLimit(int ccl)
{
	int c=0;
	if(ccl>1000 && ccl<=3000)
	{
		c=200;
	}
	else if(ccl>3000 && ccl<=5000)
	{
	c=400;	
	}
	else if(ccl>5000 && ccl>=10000)
	{
		c=600;
	}
	else if(ccl>10000)
	{
		c=800;
	}
	return c;
	
}
	}


			
	


