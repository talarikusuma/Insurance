package com.cg.insure.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.BeforeClass;
import org.junit.jupiter.api.Test;

import com.cg.insure.bean.LoginBean;
import com.cg.insure.dao.InsureDao;

class InsureTest {
	
	static InsureDao dao;
	static LoginBean bean;
	
	@BeforeClass
	public static void initialize()
	{
	dao = new InsureDao();
	bean = new LoginBean();
	}

	@Test
	void test() {
		fail("Not yet implemented");
	}
	
	@Test
	public void testUserId() 
	{
		assertEquals(10003,dao.userId());
	}
	
	@Test
	public void testSequence() 
	{
		assertNotNull(dao.seq());
	}
	
	@Test
	public void testLoginValidation()
	{
		assertNotNull(dao.LoginValidation(bean));
	}
	
	@Test
	public void testviewReport()
	{
		assertNotNull(dao.viewReport(12345, "sam190"));
	}
	
	@Test
	public void testAvailibility()
	{
		assertNotNull(dao.avalability("sam190"));
	}

}
